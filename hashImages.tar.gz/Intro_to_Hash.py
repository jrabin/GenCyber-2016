# -*- coding: utf-8 -*-
"""
Joelle Rabin- Court
GenCyber 2016
Created on Fri Jul  8 13:14:36 2016
"""
#Adding the hash library
import hashlib

#Begin defining your md5 hash
def md5(fname):
    #Prepare to hash
    hash_md5 = hashlib.md5()
    #Open a file
    with open (fname, "rb") as f:
        #For each 4096 byte chunk of the file
        for chunk in iter(lambda: f.read(4096), b""):
            #HASH IT UP IN HERE!
            hash_md5.update(chunk)
    #Give me the hash back pls, return it
    return hash_md5.hexigest()
